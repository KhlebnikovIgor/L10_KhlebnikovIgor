import UIKit

class QueueLifo<T>{
var items = [T]()
    func push(_ item: T){
      self.items.append(item)
    }
    func pop()->T {
      return self.items.removeFirst()
    }
    func indexIsValid(_ index: Int)->Bool{
        if index>=0 && index<self.items.count {return true}
        else {return false}
    }
    subscript(ind: Int)->T?{
        get{
            if indexIsValid(ind){ return items[ind]}
            else {return nil}
        }
        set{
            assert(indexIsValid(ind), "Index out of range")
            items[ind] = newValue!
        }
    }
    
    func filterString()->[T]{
        return items.filter({$0 is String})
    }
    
}


var array = QueueLifo<Any>()
array.push("один")
array.push(1)
array.push("два")
print(array.items)
print(array[2]!)
print("Строковые элементы в очереди: \(array.filterString())")
print(array[3]!)
array[3]=3
